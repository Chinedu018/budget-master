import React from "react";

const Footer = () => {
  return (
    <div>
      <div style={{ backgroundColor: "black",  color:'white', height: "100px", marginTop:'20px' }}>
        &copy; Budget Master, 2024
      </div>
    </div>
  );
};

export default Footer;
