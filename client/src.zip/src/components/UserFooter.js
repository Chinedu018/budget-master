import React from 'react';

const UserFooter = () => {
    return (
        <div>
            
        </div>
    );
};

export default UserFooter;