import React from 'react';

const AdminFooter = () => {
    return (
        <div>
            
        </div>
    );
};

export default AdminFooter;