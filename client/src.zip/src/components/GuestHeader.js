import React from 'react';

const Header = () => {
    return (
        <div>
            <div style={{backgroundColor:'black', color:'white', height:'100px', marginBottom:'10px'} }>
                <h1>Budget Master APP</h1>
            </div>          
        </div>
    );
};

export default Header;