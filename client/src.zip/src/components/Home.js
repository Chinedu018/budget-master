import React from 'react';

const Home = () => {
    return (
        <div>
          
            <h1>WELCOME TO MY PROJECT. THE HOME PAGE WILL SOON BE BEAUTIFUL</h1>
          
        </div>
    );
};

export default Home;