import React, {useEffect, useState} from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Navigate } from 'react-router-dom';
import api from './services/api'
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import About from './components/About';
import UserDashboard from './components/User/Dashboard.js';
import UserIncome from './components/User/IncomeList.js';
import AdminDashboard from './components/Admin/Dashboard.js';
import AdminManageUsers from './components/Admin/ManageUsers';
import GuestHeader from './components/GuestHeader';
import GuestFooter from './components/GuestFooter';
import UserHeader from './components/UserHeader';
import UserFooter from './components/UserFooter';
import AdminHeader from './components/AdminHeader.js';
import AdminFooter from './components/AdminFooter';
import AddIncome from './components/User/AddIncome.js';
import ProtectedRoute from './components/protectedRoute.js';
import ExpenseCategoryPage from './components/User/ExpenseCategoryPage.js';
import ExpenseForm from './components/User/ExpenseForm.js';
import ExpenseList from './components/User/ExpenseList.js';
import ExpenseCategoryForm from './components/User/ExpenseCategoryForm.js';
import Reports from './components/User/Reports.js';
import CreateResource from './components/Admin/CreateResource';
import ViewResources from './components/User/ViewResources';
import ResourceDetail from './components/User/ResourceDetail';
import AdminResourceDetail from './components/Admin/AdminResourceDetail';
import ViewEducationalResources from './components/Admin/ViewEducationalResources.js';
function App() {
  //const userRole = "guest"; // This should be dynamically set based on user authentication
   // This should be dynamically set based on user authentication

  const [userRole, setUserRole] = useState('guest');

    
        const checkAuth = async () => {
            try {
                const response = await api.get('/auth/check', { withCredentials: true });
                setUserRole(response.data.user.role.toLowerCase());
                console.log(response.data.user.role);
            } catch (err) {
              console.log(err.message);
                setUserRole('guest');
            }
            console.log(userRole)

        };

        checkAuth();
   

  const getHeader = () => {
    switch (userRole.toLowerCase()) {
      case 'standard':
        return <UserHeader />;
      case 'admin':
        return <AdminHeader />;
      default:
        // return <GuestHeader />;
        return '';
    }
  };

  const getFooter = () => {
    switch (userRole.toLowerCase()) {
      case 'standard':
        return <UserFooter />;
      case 'admin':
        return <AdminFooter />;
      default:
        //return <GuestFooter />;
        return '';

    }
  };

    return (
    <div className="App">
      
    <Router>
      {getHeader()}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/about" element={<About />} />
        <Route path="/user/dashboard" element={<ProtectedRoute><UserDashboard /></ProtectedRoute>} />
        
        <Route path="/user/income" element={<ProtectedRoute> <UserIncome /> </ProtectedRoute>} />
        <Route path="/user/addincome" element={<ProtectedRoute><AddIncome /></ProtectedRoute>} />
        <Route path="/user/income/edit/:incomeId" element={<ProtectedRoute><AddIncome /> </ProtectedRoute>} />
        
        <Route path="/user/expenses" element={<ProtectedRoute> <ExpenseList /> </ProtectedRoute>} />
        <Route path="/user/expenses/add" element={<ProtectedRoute><ExpenseForm /> </ProtectedRoute>} />
        <Route path="/user/expenses/edit/:expenseId" element={<ProtectedRoute><ExpenseForm /> </ProtectedRoute>} />

        <Route path="/user/expenses/categories" element={<ProtectedRoute><ExpenseCategoryPage /> </ProtectedRoute>} />
        <Route path="/user/expenses/categories/add" element={<ProtectedRoute><ExpenseCategoryForm /> </ProtectedRoute>} />
        <Route path="/user/expenses/categories/edit/:categoryId" element={<ProtectedRoute><ExpenseCategoryForm /> </ProtectedRoute>} />
         
                <Route path="/user/resources" element={<ProtectedRoute><ViewResources /></ProtectedRoute>} />
                <Route path="/user/resources/:resourceId" element={<ProtectedRoute><ResourceDetail /></ProtectedRoute>} />
        <Route path="/user/reports" element={<ProtectedRoute><Reports /> </ProtectedRoute>} />
        
        
        <Route path="/admin/dashboard" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/manage-users" element={<ProtectedRoute><AdminManageUsers /></ProtectedRoute>} />
        <Route path="/admin/resources/create" element={<ProtectedRoute><CreateResource /></ProtectedRoute>} />
        <Route path="/admin/resources/edit/:resourceId" element={<ProtectedRoute><CreateResource /></ProtectedRoute>} />
        <Route path="/admin/resources" element={<ProtectedRoute><ViewEducationalResources /> </ProtectedRoute>} />
        <Route path="/admin/resources/:resourceId" element={<ProtectedRoute><AdminResourceDetail /></ProtectedRoute>} />
        
      </Routes>
      {getFooter()}
    </Router>
    </div>
  );
}



export default App;
